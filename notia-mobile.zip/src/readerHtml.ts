import { Theme } from './theme';
const CDN = 'https://cdnjs.cloudflare.com/ajax/libs/';
export const readerHtml = (th: Theme) => `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<script src="${CDN}pdf.js/3.11.174/pdf.min.js"></script><script src="${CDN}jszip/3.10.1/jszip.min.js"></script><script src="${CDN}mammoth/1.6.0/mammoth.browser.min.js"></script>
<style>body{margin:0;padding:14px 16px 90px;background:${th.bg};color:${th.ink};font:18px/1.65 Georgia,serif;-webkit-user-select:text}
img{max-width:100%;height:auto}h1,h2,h3{line-height:1.25}mark{background:#FFE27A;color:#111;border-radius:3px}a{color:${th.accent}}
.pg{background:#fff;margin:8px auto}.pg canvas{display:block}#msg{padding:40px 8px;color:${th.sub};text-align:center;font:16px sans-serif}</style></head>
<body><div id="doc"><div id="msg">Loading…</div></div><script>
var RN=function(m){window.ReactNativeWebView.postMessage(JSON.stringify(m))};window.RN=RN;
var doc=document.getElementById('doc'),total=0;
function b2u(b){var s=atob(b),u=new Uint8Array(s.length);for(var i=0;i<s.length;i++)u[i]=s.charCodeAt(i);return u}
function room(){return document.documentElement.scrollHeight-innerHeight}
function prog(){var h=room(),p=h>0?scrollY/h:0;RN({type:'p',pct:Math.max(0,Math.min(1,p)),page:total?Math.min(total,Math.round(p*(total-1))+1):0,total:total})}
var tm;addEventListener('scroll',function(){clearTimeout(tm);tm=setTimeout(prog,400)});
window.jump=function(p){scrollTo(0,room()*p)};
function restore(p){setTimeout(function(){scrollTo(0,room()*p);prog()},400)}
window.load=async function(k,b,start){try{
 doc.innerHTML='';
 if(k==='pdf'){
  if(!window.pdfjsLib)throw new Error('offline');
  pdfjsLib.GlobalWorkerOptions.workerSrc='${CDN}pdf.js/3.11.174/pdf.worker.min.js';
  var pdf=await pdfjsLib.getDocument({data:b2u(b)}).promise;total=pdf.numPages;
  var p1=await pdf.getPage(1),v1=p1.getViewport({scale:1}),w=innerWidth-16,sc=w/v1.width;
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting&&!e.target.d){e.target.d=1;
   pdf.getPage(+e.target.dataset.n).then(function(pg){var vp=pg.getViewport({scale:sc*1.5}),c=document.createElement('canvas');
   c.width=vp.width;c.height=vp.height;c.style.width=w+'px';c.style.height=(vp.height/1.5)+'px';e.target.appendChild(c);pg.render({canvasContext:c.getContext('2d'),viewport:vp})})}})},{rootMargin:'800px'});
  for(var i=1;i<=total;i++){var d=document.createElement('div');d.className='pg';d.dataset.n=i;d.style.cssText='width:'+w+'px;height:'+(v1.height*sc)+'px';doc.appendChild(d);io.observe(d)}
 }else if(k==='docx'){
  if(!window.mammoth)throw new Error('offline');
  doc.innerHTML=(await mammoth.convertToHtml({arrayBuffer:b2u(b).buffer})).value;
 }else{
  if(!window.JSZip)throw new Error('offline');
  var z=await JSZip.loadAsync(b,{base64:true}),P=new DOMParser();
  var op=P.parseFromString(await z.file('META-INF/container.xml').async('string'),'text/xml').querySelector('rootfile').getAttribute('full-path');
  var opf=P.parseFromString(await z.file(op).async('string'),'text/xml'),man={};
  opf.querySelectorAll('manifest > item').forEach(function(i){man[i.getAttribute('id')]=i.getAttribute('href')});
  var base=op.indexOf('/')>-1?op.slice(0,op.lastIndexOf('/')+1):'';
  var ids=[].map.call(opf.querySelectorAll('spine > itemref'),function(r){return r.getAttribute('idref')});
  for(var i=0;i<ids.length;i++){var path=base+decodeURIComponent(man[ids[i]]||''),f=z.file(path);if(!f)continue;
   var dd=P.parseFromString(await f.async('string'),'text/html'),im=dd.querySelectorAll('img');
   for(var j=0;j<im.length;j++){var src=im[j].getAttribute('src');if(!src)continue;var ip=decodeURIComponent(new URL(src,'http://x/'+path).pathname.slice(1)),imf=z.file(ip);
    if(imf){var ex=ip.split('.').pop().toLowerCase();im[j].setAttribute('src','data:image/'+(ex==='svg'?'svg+xml':ex==='jpg'?'jpeg':ex)+';base64,'+await imf.async('base64'))}}
   var s=document.createElement('section');s.innerHTML=dd.body?dd.body.innerHTML:'';doc.appendChild(s)}
 }
 restore(start||0);RN({type:'loaded'});
}catch(e){RN({type:'err',msg:String(e&&e.message||e)})}};
window.hl=function(){var s=getSelection();if(!s.rangeCount||s.isCollapsed)return;var t=s.toString(),r=s.getRangeAt(0),m=document.createElement('mark');
 try{r.surroundContents(m)}catch(e){}RN({type:'hl',text:t});s.removeAllRanges()};
addEventListener('load',function(){RN({type:'ready'})});
</script></body></html>`;
