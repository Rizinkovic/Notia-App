import React, { createContext, useContext, useEffect, useRef, useState, useCallback, useMemo } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as N from 'expo-notifications';
import { Platform } from 'react-native';
import { uid } from './store';

export type Mark = { id: string; pct: number; page: number; text?: string };
export type Book = { id: string; title: string; kind: 'pdf' | 'epub' | 'docx'; uri: string; pct: number; page: number; total: number; time: number; last: number; bm: Mark[]; hl: Mark[] };
export const MAX_BOOKS = 10;
const KEY = 'notia:lib', RKEY = 'notia:lib.remind';

type Ctx = { books: Book[]; ready: boolean; add: (b: Omit<Book, 'id' | 'pct' | 'page' | 'total' | 'time' | 'last' | 'bm' | 'hl'>) => string; patch: (id: string, p: Partial<Book> | ((b: Book) => Partial<Book>)) => void; remove: (id: string) => void };
const C = createContext<Ctx>(null as any);
export const useLib = () => useContext(C);
export const fmtTime = (s: number) => { const m = Math.floor(s / 60); return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m` : `${m}m`; };

export function LibProvider({ children, lang }: { children: React.ReactNode; lang: 'en' | 'fr' }) {
  const [books, setBooks] = useState<Book[]>([]);
  const [ready, setReady] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  useEffect(() => { AsyncStorage.getItem(KEY).then(v => v && setBooks(JSON.parse(v))).catch(() => {}).finally(() => setReady(true)); }, []);
  useEffect(() => {
    if (!ready) return;
    clearTimeout(timer.current);
    timer.current = setTimeout(() => AsyncStorage.setItem(KEY, JSON.stringify(books)).catch(() => {}), 500);
  }, [books, ready]);

  // Daily 7pm reminder to finish the most-read unfinished book.
  const topTitle = useMemo(() => books.filter(b => b.pct < 0.97 && b.time > 0).sort((a, b) => b.time - a.time)[0]?.title ?? '', [books]);
  useEffect(() => {
    if (!ready) return;
    (async () => {
      try {
        const old = await AsyncStorage.getItem(RKEY);
        if (old) await N.cancelScheduledNotificationAsync(old).catch(() => {});
        await AsyncStorage.removeItem(RKEY);
        if (!topTitle) return;
        const p = await N.requestPermissionsAsync();
        if (!p.granted) return;
        if (Platform.OS === 'android') await N.setNotificationChannelAsync('reading', { name:'Reading', importance:N.AndroidImportance.DEFAULT });
        const id = await N.scheduleNotificationAsync({
          content:{ title:'Notia', body: lang === 'fr' ? `Terminez « ${topTitle} » ce soir ?` : `Finish “${topTitle}” tonight?` },
          trigger:{ type:N.SchedulableTriggerInputTypes.DAILY, hour:19, minute:0, channelId:'reading' } as any,
        });
        await AsyncStorage.setItem(RKEY, id);
      } catch {}
    })();
  }, [topTitle, ready, lang]);

  const add = useCallback<Ctx['add']>(b => {
    const id = uid();
    setBooks(p => [{ ...b, id, pct:0, page:0, total:0, time:0, last:Date.now(), bm:[], hl:[] }, ...p]);
    return id;
  }, []);
  const patch = useCallback<Ctx['patch']>((id, p) => setBooks(bs => bs.map(b => b.id === id ? { ...b, ...(typeof p === 'function' ? p(b) : p) } : b)), []);
  const remove = useCallback((id: string) => setBooks(p => p.filter(b => b.id !== id)), []);
  const value = useMemo(() => ({ books, ready, add, patch, remove }), [books, ready, add, patch, remove]);
  return <C.Provider value={value}>{children}</C.Provider>;
}
