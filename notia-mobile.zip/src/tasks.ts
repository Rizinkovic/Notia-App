import * as N from 'expo-notifications';
import { Platform } from 'react-native';

export type Task = { id: string; title: string; due: number | null; done: boolean; nid?: string };
export const TASKS_KEY = 'notia:tasks';

N.setNotificationHandler({
  handleNotification: async () => ({ shouldShowAlert: true, shouldShowBanner: true, shouldShowList: true, shouldPlaySound: false, shouldSetBadge: false } as any),
});

export async function schedule(title: string, due: number): Promise<string | undefined> {
  try {
    const p = await N.requestPermissionsAsync();
    if (!p.granted) return undefined;
    if (Platform.OS === 'android')
      await N.setNotificationChannelAsync('tasks', { name:'Tasks', importance:N.AndroidImportance.HIGH });
    return await N.scheduleNotificationAsync({
      content:{ title:'Notia', body:title },
      trigger:{ type:N.SchedulableTriggerInputTypes.DATE, date:new Date(due), channelId:'tasks' } as any,
    });
  } catch { return undefined; }
}
export const cancel = (nid?: string) => (nid ? N.cancelScheduledNotificationAsync(nid).catch(() => {}) : Promise.resolve());
