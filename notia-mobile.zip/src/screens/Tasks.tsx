import React, { useEffect, useRef, useState } from 'react';
import { View, Text, TextInput, FlatList, Pressable, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useApp, uid } from '../store';
import { L } from '../i18n';
import { Task, TASKS_KEY, schedule, cancel } from '../tasks';

const at = (daysAhead: number, h: number) => { const d = new Date(); d.setDate(d.getDate() + daysAhead); d.setHours(h, 0, 0, 0); return d.getTime(); };

export default function Tasks() {
  const { s, th } = useApp();
  const l = s.lang;
  const ins = useSafeAreaInsets();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [ready, setReady] = useState(false);
  const [text, setText] = useState('');
  const [due, setDue] = useState<number | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  useEffect(() => { AsyncStorage.getItem(TASKS_KEY).then(v => v && setTasks(JSON.parse(v))).catch(() => {}).finally(() => setReady(true)); }, []);
  useEffect(() => {
    if (!ready) return;
    clearTimeout(timer.current);
    timer.current = setTimeout(() => AsyncStorage.setItem(TASKS_KEY, JSON.stringify(tasks)).catch(() => {}), 300);
  }, [tasks, ready]);

  const opts: [string, number][] = [
    [L(l, 'In 1 hour', 'Dans 1 h'), Date.now() + 3600000],
    [L(l, 'Tonight 8pm', 'Ce soir 20h'), at(0, 20)],
    [L(l, 'Tomorrow 9am', 'Demain 9h'), at(1, 9)],
  ];
  const add = async () => {
    const title = text.trim();
    if (!title) return;
    const nid = due && due > Date.now() ? await schedule(title, due) : undefined;
    setTasks(p => [{ id:uid(), title, due, done:false, nid }, ...p]);
    setText(''); setDue(null);
  };
  const toggle = (tk: Task) => { if (!tk.done) cancel(tk.nid); setTasks(p => p.map(x => x.id === tk.id ? { ...x, done:!x.done } : x)); };
  const remove = (tk: Task) => { cancel(tk.nid); setTasks(p => p.filter(x => x.id !== tk.id)); };
  const sorted = [...tasks].sort((a, b) => Number(a.done) - Number(b.done) || (a.due ?? Infinity) - (b.due ?? Infinity));
  const fmt = (n: number) => new Date(n).toLocaleString(l, { dateStyle:'medium', timeStyle:'short' });

  return (
    <View style={{ flex:1, backgroundColor:th.bg, paddingTop:ins.top + 12 }}>
      <Text style={[st.h1, { color:th.ink }]}>{L(l, 'Tasks', 'Tâches')}</Text>
      <View style={{ paddingHorizontal:20, gap:10 }}>
        <View style={[st.row, { backgroundColor:th.card, borderColor:th.line }]}>
          <TextInput value={text} onChangeText={setText} onSubmitEditing={add} returnKeyType="done"
            placeholder={L(l, 'What needs doing?', 'Que faut-il faire ?')} placeholderTextColor={th.sub} style={{ flex:1, color:th.ink, paddingVertical:12 }} />
          <Pressable onPress={add} hitSlop={10}><Ionicons name="add-circle" size={30} color={th.accent} /></Pressable>
        </View>
        <View style={{ flexDirection:'row', gap:8, flexWrap:'wrap' }}>
          {opts.map(([label, ts]) => (
            <Pressable key={label} onPress={() => setDue(due === ts ? null : ts)}
              style={[st.chip, { borderColor:th.line, backgroundColor:due === ts ? th.accent : th.card }]}>
              <Ionicons name="alarm-outline" size={14} color={due === ts ? th.accentInk : th.sub} />
              <Text style={{ color:due === ts ? th.accentInk : th.ink, fontWeight:'600', fontSize:13 }}>{label}</Text>
            </Pressable>
          ))}
        </View>
      </View>
      <FlatList data={sorted} keyExtractor={t => t.id} contentContainerStyle={{ padding:20, paddingBottom:170, gap:10 }}
        ListEmptyComponent={<Text style={{ color:th.sub, textAlign:'center', marginTop:50 }}>{L(l, 'No tasks. Add one above, with a reminder if it matters.', 'Aucune tâche. Ajoutez-en une, avec un rappel si besoin.')}</Text>}
        renderItem={({ item }) => (
          <Pressable onLongPress={() => remove(item)} onPress={() => toggle(item)} style={[st.row, { backgroundColor:th.card, borderColor:th.line, paddingVertical:14 }]}>
            <Ionicons name={item.done ? 'checkmark-circle' : 'ellipse-outline'} size={24} color={item.done ? th.accent : th.sub} />
            <View style={{ flex:1 }}>
              <Text style={{ color:th.ink, fontWeight:'600', textDecorationLine:item.done ? 'line-through' : 'none', opacity:item.done ? 0.5 : 1 }}>{item.title}</Text>
              {item.due ? <Text style={{ color:th.sub, fontSize:12, marginTop:2 }}>{fmt(item.due)}</Text> : null}
            </View>
            <Pressable onPress={() => remove(item)} hitSlop={10}><Ionicons name="trash-outline" size={20} color={th.sub} /></Pressable>
          </Pressable>
        )} />
    </View>
  );
}
const st = StyleSheet.create({
  h1:{ fontSize:32, fontWeight:'800', paddingHorizontal:20, marginBottom:12 },
  row:{ flexDirection:'row', alignItems:'center', gap:12, paddingHorizontal:14, borderRadius:18, borderWidth:1 },
  chip:{ flexDirection:'row', alignItems:'center', gap:6, paddingHorizontal:12, height:32, borderRadius:16, borderWidth:1 },
});
