import React from 'react';
import { View, Text, FlatList, Pressable, Alert, StyleSheet } from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import { File, Paths } from 'expo-file-system';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../store';
import { useLib, fmtTime, MAX_BOOKS, Book } from '../library';
import { L } from '../i18n';

export default function Library({ navigation }: any) {
  const { s, th } = useApp();
  const l = s.lang;
  const { books, add, remove } = useLib();
  const ins = useSafeAreaInsets();
  const total = books.reduce((a, b) => a + b.time, 0);

  const pick = async () => {
    if (books.length >= MAX_BOOKS) return Alert.alert(L(l, 'Library full', 'Bibliothèque pleine'), L(l, `The library holds ${MAX_BOOKS} books. Remove one first.`, `La bibliothèque contient ${MAX_BOOKS} livres. Supprimez-en un d’abord.`));
    try {
      const r = await DocumentPicker.getDocumentAsync({ type:'*/*', copyToCacheDirectory:true });
      const a = r.assets?.[0];
      if (r.canceled || !a) return;
      const ext = (a.name.split('.').pop() || '').toLowerCase();
      if (ext === 'mobi' || ext === 'azw3') return Alert.alert('MOBI', L(l, 'MOBI files can’t be opened yet. Convert the book to EPUB (for example with Calibre) and add it again.', 'Les fichiers MOBI ne sont pas encore pris en charge. Convertissez le livre en EPUB (par exemple avec Calibre) puis ajoutez-le.'));
      if (!['pdf', 'epub', 'docx'].includes(ext)) return Alert.alert(L(l, 'Unsupported file', 'Fichier non pris en charge'), L(l, 'Choose a PDF, EPUB or DOCX file.', 'Choisissez un fichier PDF, EPUB ou DOCX.'));
      const dest = new File(Paths.document, `${Date.now()}.${ext}`);
      new File(a.uri).copy(dest);
      navigation.navigate('Reader', { id:add({ title:a.name.replace(/\.[^.]+$/, ''), kind:ext as Book['kind'], uri:dest.uri }) });
    } catch { Alert.alert(L(l, 'Could not add the book', 'Impossible d’ajouter le livre'), L(l, 'Try again, or pick another file.', 'Réessayez, ou choisissez un autre fichier.')); }
  };
  const del = (b: Book) => Alert.alert(L(l, 'Remove this book?', 'Retirer ce livre ?'), b.title, [
    { text:L(l, 'Cancel', 'Annuler'), style:'cancel' },
    { text:L(l, 'Remove', 'Retirer'), style:'destructive', onPress:() => { try { new File(b.uri).delete(); } catch {} remove(b.id); } },
  ]);

  return (
    <View style={{ flex:1, backgroundColor:th.bg, paddingTop:ins.top + 12 }}>
      <Text style={[st.h1, { color:th.ink }]}>{L(l, 'Library', 'Bibliothèque')}</Text>
      <View style={[st.stats, { backgroundColor:th.card, borderColor:th.line }]}>
        <View><Text style={{ color:th.ink, fontSize:24, fontWeight:'800' }}>{fmtTime(total)}</Text><Text style={{ color:th.sub }}>{L(l, 'Total reading time', 'Temps de lecture total')}</Text></View>
        <View style={{ alignItems:'flex-end' }}><Text style={{ color:th.ink, fontSize:24, fontWeight:'800' }}>{books.length}/{MAX_BOOKS}</Text><Text style={{ color:th.sub }}>{L(l, 'Books', 'Livres')}</Text></View>
      </View>
      <FlatList data={books} keyExtractor={b => b.id} contentContainerStyle={{ padding:20, paddingBottom:170, gap:12 }}
        ListEmptyComponent={<Text style={{ color:th.sub, textAlign:'center', marginTop:40 }}>{L(l, 'No books yet. Tap + to add a PDF, EPUB or DOCX.', 'Aucun livre. Touchez + pour ajouter un PDF, EPUB ou DOCX.')}</Text>}
        renderItem={({ item }) => (
          <Pressable onPress={() => navigation.navigate('Reader', { id:item.id })} onLongPress={() => del(item)} style={[st.card, { backgroundColor:th.card, borderColor:th.line }]}>
            <View style={[st.cover, { backgroundColor:th.accent }]}><Text style={{ color:th.accentInk, fontWeight:'800' }}>{item.kind.toUpperCase()}</Text></View>
            <View style={{ flex:1 }}>
              <Text numberOfLines={2} style={{ color:th.ink, fontWeight:'700', fontSize:16 }}>{item.title}</Text>
              <View style={[st.track, { backgroundColor:th.line }]}><View style={{ width:`${Math.round(item.pct * 100)}%`, height:6, borderRadius:3, backgroundColor:th.accent }} /></View>
              <Text style={{ color:th.sub, fontSize:12 }}>{Math.round(item.pct * 100)}%  •  {fmtTime(item.time)}{item.total ? `  •  p. ${item.page}/${item.total}` : ''}</Text>
            </View>
          </Pressable>
        )} />
      <Pressable accessibilityLabel="Add book" onPress={pick} style={[st.fab, { backgroundColor:th.accent, bottom:ins.bottom + 84 }]}>
        <Ionicons name="add" size={28} color={th.accentInk} />
      </Pressable>
    </View>
  );
}
const st = StyleSheet.create({
  h1:{ fontSize:32, fontWeight:'800', paddingHorizontal:20, marginBottom:12 },
  stats:{ flexDirection:'row', justifyContent:'space-between', marginHorizontal:20, padding:16, borderRadius:22, borderWidth:1 },
  card:{ flexDirection:'row', gap:14, padding:14, borderRadius:22, borderWidth:1, alignItems:'center' },
  cover:{ width:56, height:76, borderRadius:10, alignItems:'center', justifyContent:'center' },
  track:{ height:6, borderRadius:3, marginVertical:8 },
  fab:{ position:'absolute', right:20, width:56, height:56, borderRadius:28, alignItems:'center', justifyContent:'center', elevation:6 },
});
