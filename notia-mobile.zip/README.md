# Notia Mobile (Android) - Expo SDK 58, React Native, TypeScript
1. Install Node.js 20+ and start your Android emulator.
2. Windows: double-click run.bat. Mac/Linux: sh run.sh
   (or: npm install, then npx expo start --android; press a if the emulator is not picked up)
Allow notifications when asked, so task and reading reminders work.
The book reader needs internet the first time it opens a book (it loads its PDF/EPUB/DOCX engines).
